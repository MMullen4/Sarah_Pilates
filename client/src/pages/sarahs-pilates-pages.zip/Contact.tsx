import React from "react";

const Contact: React.FC = () => {
  return (
    <div className="p-10 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-orange-600 mb-4">Contact</h1>
      <p>A contact form to reach Sarah's Pilates.</p>
    </div>
  );
};

export default Contact;
