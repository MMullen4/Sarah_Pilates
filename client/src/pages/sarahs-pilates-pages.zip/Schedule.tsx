import React from "react";

const Schedule: React.FC = () => {
  return (
    <div className="p-10 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-orange-600 mb-4">Schedule</h1>
      <p>A calendar and booking form for scheduling appointments.</p>
    </div>
  );
};

export default Schedule;
