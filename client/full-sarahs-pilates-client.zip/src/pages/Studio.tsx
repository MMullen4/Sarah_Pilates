import React from "react";

const Studio: React.FC = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Studio Page</h1>
      <p>Welcome to the Studio page of Sarah's Pilates!</p>
    </div>
  );
};

export default Studio;
