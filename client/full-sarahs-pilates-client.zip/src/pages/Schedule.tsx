import React from "react";

const Schedule: React.FC = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Schedule Page</h1>
      <p>Welcome to the Schedule page of Sarah's Pilates!</p>
    </div>
  );
};

export default Schedule;
