import React from "react";

const Contact: React.FC = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Contact Page</h1>
      <p>Welcome to the Contact page of Sarah's Pilates!</p>
    </div>
  );
};

export default Contact;
