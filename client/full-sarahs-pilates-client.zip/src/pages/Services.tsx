import React from "react";

const Services: React.FC = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Services Page</h1>
      <p>Welcome to the Services page of Sarah's Pilates!</p>
    </div>
  );
};

export default Services;
